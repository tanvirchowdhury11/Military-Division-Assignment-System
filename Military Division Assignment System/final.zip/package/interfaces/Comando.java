package interfaces;
import classes.*;
public interface Comando
{
	public void join();
}