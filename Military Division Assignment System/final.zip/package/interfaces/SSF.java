package interfaces;
import classes.*;
public interface SSF
{
	public void join();
}